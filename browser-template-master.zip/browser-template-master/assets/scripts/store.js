'use strict'

const store = {
}

module.exports = store
