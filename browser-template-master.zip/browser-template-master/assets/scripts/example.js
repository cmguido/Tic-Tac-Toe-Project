const element = document.createElement('div')
element.id = 'myDiv'
element.innerHTML = 'Hello World!'
document.body.appendChild(element)
